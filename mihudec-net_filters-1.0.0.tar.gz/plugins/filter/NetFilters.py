from net_templates.filters import NetFilters

class FilterModule(object):
    
    def filters(self):
        return NetFilters().filters()
